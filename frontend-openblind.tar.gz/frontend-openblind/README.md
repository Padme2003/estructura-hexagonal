# OpenBlind Frontend

Aplicación de navegación accesible para personas con vista parcial y adultos mayores.

## 🎯 Características

- ✅ Diseño accesible para vista parcial
- ✅ Paleta de colores para daltonismo (morado/púrpura)
- ✅ Botones grandes para adultos mayores
- ✅ Comandos de voz (Web Speech API)
- ✅ Interfaz táctil y por voz

## 🚀 Instalación

```bash
npm install
```

## 💻 Desarrollo

```bash
npm run dev
```

La aplicación se ejecutará en `http://localhost:3000`

**IMPORTANTE:** El backend debe estar corriendo en `http://localhost:8888`

## 📦 Build para producción

```bash
npm run build
```

## 🛠️ Tecnologías

- React 18
- Vite
- React Router DOM v6
- Axios
- Web Speech API

## 📱 Módulos

1. **Lugares Favoritos** - CRUD completo (táctil + voz)
2. **Contactos de Emergencia** - CRUD completo (táctil + voz)
3. **Ubicación Actual** - GPS y navegación
4. **Rutas Frecuentes** - (Próxima versión)

## 🎨 Paleta de Colores

- Púrpura principal: `#7C3AED`
- Ámbar acento: `#F59E0B`
- Sin azul ni verde (daltonismo friendly)

## 📞 Backend

Repositorio backend: [estructura-hexagonal](https://github.com/Padme2003/estructura-hexagonal)
