import { useState, useEffect, useCallback, useRef } from 'react'

/**
 * Hook para comandos de voz usando Web Speech API
 * @param {Function} onCommand - Callback que recibe el texto reconocido
 * @param {Object} options - Opciones de configuración
 * @returns {Object} - Estado y funciones para controlar el reconocimiento
 */
export function useVoiceCommands(onCommand, options = {}) {
  const {
    language = 'es-EC', // Español de Ecuador
    continuous = true,
    interimResults = false,
    autoStart = false
  } = options

  const [isListening, setIsListening] = useState(false)
  const [transcript, setTranscript] = useState('')
  const [isSupported, setIsSupported] = useState(false)
  const [error, setError] = useState(null)

  const recognitionRef = useRef(null)

  // Verificar soporte del navegador
  useEffect(() => {
    const SpeechRecognition =
      window.SpeechRecognition || window.webkitSpeechRecognition

    if (SpeechRecognition) {
      setIsSupported(true)
      recognitionRef.current = new SpeechRecognition()

      const recognition = recognitionRef.current
      recognition.lang = language
      recognition.continuous = continuous
      recognition.interimResults = interimResults

      // Eventos
      recognition.onresult = (event) => {
        const last = event.results.length - 1
        const text = event.results[last][0].transcript.toLowerCase().trim()

        setTranscript(text)

        if (onCommand && typeof onCommand === 'function') {
          onCommand(text)
        }
      }

      recognition.onstart = () => {
        setIsListening(true)
        setError(null)
      }

      recognition.onend = () => {
        setIsListening(false)
      }

      recognition.onerror = (event) => {
        console.error('Error de reconocimiento de voz:', event.error)
        setError(event.error)
        setIsListening(false)

        // Mostrar mensaje de error amigable
        if (event.error === 'no-speech') {
          console.log('No se detectó voz')
        } else if (event.error === 'not-allowed') {
          console.error('Permisos de micrófono denegados')
        }
      }

      // Auto-iniciar si está configurado
      if (autoStart) {
        try {
          recognition.start()
        } catch (err) {
          console.error('Error al iniciar reconocimiento:', err)
        }
      }

      // Cleanup
      return () => {
        if (recognition) {
          recognition.stop()
        }
      }
    } else {
      setIsSupported(false)
      console.warn('Web Speech API no soportada en este navegador')
    }
  }, [language, continuous, interimResults, autoStart, onCommand])

  // Iniciar reconocimiento
  const startListening = useCallback(() => {
    if (recognitionRef.current && !isListening) {
      try {
        recognitionRef.current.start()
      } catch (err) {
        console.error('Error al iniciar:', err)
      }
    }
  }, [isListening])

  // Detener reconocimiento
  const stopListening = useCallback(() => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop()
    }
  }, [isListening])

  // Toggle
  const toggleListening = useCallback(() => {
    if (isListening) {
      stopListening()
    } else {
      startListening()
    }
  }, [isListening, startListening, stopListening])

  return {
    isListening,
    transcript,
    isSupported,
    error,
    startListening,
    stopListening,
    toggleListening
  }
}

/**
 * Función auxiliar para hacer que la app hable (Text-to-Speech)
 * @param {string} text - Texto a hablar
 * @param {Object} options - Opciones de voz
 */
export function hablar(text, options = {}) {
  if ('speechSynthesis' in window) {
    const utterance = new SpeechSynthesisUtterance(text)
    utterance.lang = options.lang || 'es-EC'
    utterance.rate = options.rate || 0.9 // Más lento para adultos mayores
    utterance.pitch = options.pitch || 1.0
    utterance.volume = options.volume || 1.0

    window.speechSynthesis.speak(utterance)
  } else {
    console.warn('Text-to-Speech no soportado')
  }
}

export default useVoiceCommands
