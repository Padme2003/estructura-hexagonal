import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Dashboard from './pages/Dashboard'
import LugaresFavoritos from './pages/LugaresFavoritos'
import ContactosEmergencia from './pages/ContactosEmergencia'
import UbicacionActual from './pages/UbicacionActual'
import Login from './pages/Login'

function App() {
  return (
    <Router>
      <div className="mobile-container">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/lugares" element={<LugaresFavoritos />} />
          <Route path="/contactos" element={<ContactosEmergencia />} />
          <Route path="/ubicacion" element={<UbicacionActual />} />
          <Route path="/login" element={<Login />} />
        </Routes>
      </div>
    </Router>
  )
}

export default App
