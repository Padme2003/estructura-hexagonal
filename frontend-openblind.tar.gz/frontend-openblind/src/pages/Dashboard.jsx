import { useNavigate } from 'react-router-dom'
import Navbar from '../components/Navbar'
import VoiceButton from '../components/VoiceButton'
import { useVoiceCommands, hablar } from '../hooks/useVoiceCommands'
import './Dashboard.css'

function Dashboard() {
  const navigate = useNavigate()

  // Comandos de voz para navegación
  const handleVoiceCommand = (command) => {
    console.log('Comando recibido:', command)

    // Navegación a módulos
    if (command.includes('lugares') || command.includes('lugar')) {
      hablar('Abriendo lugares favoritos')
      navigate('/lugares')
    } else if (command.includes('contactos') || command.includes('contacto')) {
      hablar('Abriendo contactos de emergencia')
      navigate('/contactos')
    } else if (command.includes('ubicación') || command.includes('ubicacion') || command.includes('dónde estoy') || command.includes('donde estoy')) {
      hablar('Mostrando tu ubicación actual')
      navigate('/ubicacion')
    } else if (command.includes('inicio') || command.includes('menú') || command.includes('menu')) {
      hablar('Ya estás en el inicio')
    } else if (command.includes('login') || command.includes('sesión') || command.includes('sesion')) {
      hablar('Abriendo login')
      navigate('/login')
    }
  }

  const { isListening, toggleListening } = useVoiceCommands(handleVoiceCommand)

  const modulos = [
    {
      id: 'lugares',
      icon: 'bookmark',
      title: 'Lugares Favoritos',
      description: 'Guarda tus sitios frecuentes',
      color: 'lugares',
      path: '/lugares',
      status: 'functional'
    },
    {
      id: 'contactos',
      icon: 'contacts',
      title: 'Contactos',
      description: 'Emergencia y familia',
      color: 'contactos',
      path: '/contactos',
      status: 'functional'
    },
    {
      id: 'ubicacion',
      icon: 'my_location',
      title: 'Mi Ubicación',
      description: 'Dónde estás ahora',
      color: 'ubicacion',
      path: '/ubicacion',
      status: 'basic'
    },
    {
      id: 'rutas',
      icon: 'route',
      title: 'Rutas Frecuentes',
      description: 'Próximamente',
      color: 'rutas',
      path: '#',
      status: 'coming-soon'
    }
  ]

  const handleModuleClick = (modulo) => {
    if (modulo.status !== 'coming-soon') {
      navigate(modulo.path)
    } else {
      hablar('Esta función estará disponible próximamente')
    }
  }

  return (
    <div className="dashboard">
      <Navbar title="OpenBlind" showLogin={true} />

      <div className="voice-announcement">
        <div className="voice-announcement-icon">
          <span className="material-icons-round">campaign</span>
        </div>
        <div className="voice-announcement-text">
          <h3>🔊 Bienvenido a OpenBlind</h3>
          <p>
            Di "Lugares", "Contactos" o "Ubicación" para navegar.
            También puedes tocar los botones grandes.
          </p>
        </div>
      </div>

      <div className="modules-grid">
        {modulos.map((modulo) => (
          <div
            key={modulo.id}
            className={`module-card ${modulo.status === 'coming-soon' ? 'module-disabled' : ''}`}
            onClick={() => handleModuleClick(modulo)}
          >
            <div className={`module-icon ${modulo.color}`}>
              <span className="material-icons-round">{modulo.icon}</span>
            </div>
            <h3 className="module-title">{modulo.title}</h3>
            <p className="module-desc">{modulo.description}</p>
            {modulo.status === 'functional' && (
              <span className="module-badge">✅ Funcional</span>
            )}
            {modulo.status === 'coming-soon' && (
              <span className="module-badge coming-soon">🔜 Próximamente</span>
            )}
          </div>
        ))}
      </div>

      <VoiceButton
        isListening={isListening}
        onToggle={toggleListening}
      />
    </div>
  )
}

export default Dashboard
