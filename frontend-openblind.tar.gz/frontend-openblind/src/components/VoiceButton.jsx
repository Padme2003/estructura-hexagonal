import { useState } from 'react'
import './VoiceButton.css'

function VoiceButton({ onCommand, isListening: externalIsListening, onToggle }) {
  const [internalIsListening, setInternalIsListening] = useState(false)

  // Usar estado externo si se proporciona, sino usar interno
  const isListening = externalIsListening !== undefined ? externalIsListening : internalIsListening

  const handleClick = () => {
    if (onToggle) {
      onToggle()
    } else {
      setInternalIsListening(!isListening)
    }
  }

  return (
    <button
      className={`voice-button ${isListening ? 'voice-button-listening' : ''}`}
      onClick={handleClick}
      aria-label={isListening ? 'Detener comandos de voz' : 'Activar comandos de voz'}
    >
      <span className={`material-icons-round voice-icon ${isListening ? 'pulse' : ''}`}>
        {isListening ? 'mic' : 'mic_none'}
      </span>
      <span className="voice-text">
        {isListening ? 'ESCUCHANDO...' : 'COMANDO DE VOZ'}
      </span>
    </button>
  )
}

export default VoiceButton
