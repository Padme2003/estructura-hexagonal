import { useNavigate } from 'react-router-dom'
import './Navbar.css'

function Navbar({ title = "OpenBlind", showBack = false, showLogin = true }) {
  const navigate = useNavigate()

  return (
    <nav className="navbar">
      <div className="navbar-brand">
        {showBack ? (
          <button className="btn-back" onClick={() => navigate(-1)} aria-label="Volver">
            <span className="material-icons-round">arrow_back</span>
          </button>
        ) : (
          <>
            <div className="navbar-logo" aria-hidden="true">
              👁️
            </div>
            <span className="navbar-title">{title}</span>
          </>
        )}
        {showBack && <h2 className="navbar-title">{title}</h2>}
      </div>

      {showLogin && (
        <div className="navbar-actions">
          <button
            className="navbar-btn"
            onClick={() => navigate('/login')}
            aria-label="Iniciar sesión"
          >
            <span className="material-icons-round">person</span>
          </button>
        </div>
      )}
    </nav>
  )
}

export default Navbar
