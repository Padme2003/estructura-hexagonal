import './Button.css'

function Button({
  children,
  onClick,
  variant = 'primary',
  size = 'large',
  icon,
  disabled = false,
  fullWidth = false,
  type = 'button',
  ...props
}) {
  const className = `btn btn-${variant} btn-${size} ${fullWidth ? 'btn-full' : ''}`

  return (
    <button
      className={className}
      onClick={onClick}
      disabled={disabled}
      type={type}
      {...props}
    >
      {icon && <span className="material-icons-round btn-icon">{icon}</span>}
      <span className="btn-text">{children}</span>
    </button>
  )
}

export default Button
