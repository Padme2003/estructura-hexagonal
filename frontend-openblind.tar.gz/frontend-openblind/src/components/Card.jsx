import './Card.css'

function Card({ children, className = '', onClick, ...props }) {
  const cardClassName = `card ${className} ${onClick ? 'card-clickable' : ''}`

  return (
    <div className={cardClassName} onClick={onClick} {...props}>
      {children}
    </div>
  )
}

export default Card
