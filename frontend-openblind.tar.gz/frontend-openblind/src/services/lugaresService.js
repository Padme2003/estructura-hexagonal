import api from './api'

const lugaresService = {
  /**
   * Obtener todos los lugares activos
   */
  getAll: async () => {
    try {
      const response = await api.get('/lugares')
      return response.data
    } catch (error) {
      console.error('Error al obtener lugares:', error)
      throw error
    }
  },

  /**
   * Obtener un lugar por ID
   */
  getById: async (id) => {
    try {
      const response = await api.get(`/lugares/${id}`)
      return response.data
    } catch (error) {
      console.error('Error al obtener lugar:', error)
      throw error
    }
  },

  /**
   * Crear nuevo lugar
   */
  create: async (lugarData) => {
    try {
      const response = await api.post('/lugares', lugarData)
      return response.data
    } catch (error) {
      console.error('Error al crear lugar:', error)
      throw error
    }
  },

  /**
   * Actualizar lugar existente
   */
  update: async (id, lugarData) => {
    try {
      const response = await api.put(`/lugares/${id}`, lugarData)
      return response.data
    } catch (error) {
      console.error('Error al actualizar lugar:', error)
      throw error
    }
  },

  /**
   * Eliminar (desactivar) lugar
   */
  delete: async (id) => {
    try {
      const response = await api.delete(`/lugares/${id}`)
      return response.data
    } catch (error) {
      console.error('Error al eliminar lugar:', error)
      throw error
    }
  },

  /**
   * Buscar lugar por nombre (para comandos de voz)
   */
  buscarPorNombre: async (nombre) => {
    try {
      const lugares = await lugaresService.getAll()
      const lugarEncontrado = lugares.find((l) =>
        l.nombreLugar.toLowerCase().includes(nombre.toLowerCase())
      )
      return lugarEncontrado
    } catch (error) {
      console.error('Error al buscar lugar:', error)
      throw error
    }
  }
}

export default lugaresService
