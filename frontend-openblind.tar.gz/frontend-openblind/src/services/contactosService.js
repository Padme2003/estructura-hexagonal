import api from './api'

const contactosService = {
  /**
   * Obtener todos los contactos de un cliente
   */
  getAll: async (clienteId) => {
    try {
      const response = await api.get(`/contactos-emergencia/cliente/${clienteId}`)
      return response.data
    } catch (error) {
      console.error('Error al obtener contactos:', error)
      throw error
    }
  },

  /**
   * Obtener un contacto por ID
   */
  getById: async (id) => {
    try {
      const response = await api.get(`/contactos-emergencia/${id}`)
      return response.data
    } catch (error) {
      console.error('Error al obtener contacto:', error)
      throw error
    }
  },

  /**
   * Obtener contacto prioritario (para emergencias)
   */
  getPrioritario: async (clienteId) => {
    try {
      const response = await api.get(`/contactos-emergencia/prioritario/${clienteId}`)
      return response.data
    } catch (error) {
      console.error('Error al obtener contacto prioritario:', error)
      throw error
    }
  },

  /**
   * Crear nuevo contacto
   */
  create: async (contactoData) => {
    try {
      const response = await api.post('/contactos-emergencia', contactoData)
      return response.data
    } catch (error) {
      console.error('Error al crear contacto:', error)
      throw error
    }
  },

  /**
   * Actualizar contacto existente
   */
  update: async (id, contactoData) => {
    try {
      const response = await api.put(`/contactos-emergencia/${id}`, contactoData)
      return response.data
    } catch (error) {
      console.error('Error al actualizar contacto:', error)
      throw error
    }
  },

  /**
   * Eliminar (desactivar) contacto
   */
  delete: async (id) => {
    try {
      const response = await api.delete(`/contactos-emergencia/${id}`)
      return response.data
    } catch (error) {
      console.error('Error al eliminar contacto:', error)
      throw error
    }
  },

  /**
   * Buscar contacto por nombre (para comandos de voz)
   */
  buscarPorNombre: async (clienteId, nombre) => {
    try {
      const response = await api.get(`/contactos-emergencia/buscar/${clienteId}/${nombre}`)
      return response.data
    } catch (error) {
      console.error('Error al buscar contacto:', error)
      throw error
    }
  },

  /**
   * Llamar a un contacto (abre el marcador del teléfono)
   */
  llamar: (telefono) => {
    window.location.href = `tel:${telefono}`
  }
}

export default contactosService
