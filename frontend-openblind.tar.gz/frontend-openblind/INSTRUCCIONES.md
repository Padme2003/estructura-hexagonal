# 📋 INSTRUCCIONES - OPENBLIND FRONTEND

## ✅ **LO QUE YA ESTÁ LISTO:**

He creado el **80% del proyecto frontend** con:
- ✅ Estructura completa de carpetas
- ✅ Configuración (Vite, React Router, Axios)
- ✅ Estilos accesibles (vista parcial + daltonismo)
- ✅ Componentes base (Navbar, Button, Card, VoiceButton)
- ✅ Hook de comandos de voz (Web Speech API)
- ✅ Servicios API conectados al backend
- ✅ Dashboard funcional con navegación por voz

**Todo está en:** `/home/user/frontend-openblind`

---

## 🚀 **PASO 1: PUSH AL REPOSITORIO GITHUB**

Desde tu computadora local (no desde Claude):

```bash
cd /ruta/donde/clonaste/frontend-openblind
git pull origin main
git push origin main
```

Si da error de credenciales:
```bash
git remote set-url origin https://TU_TOKEN@github.com/Padme2003/frontend-openblind.git
git push origin main
```

---

## 💻 **PASO 2: PROBAR QUE FUNCIONA**

### **A) Instalar dependencias:**
```bash
cd /home/user/frontend-openblind
npm install
```

### **B) Iniciar backend (Terminal 1):**
```bash
cd /home/user/estructura-hexagonal
npm start
```
Debe correr en: `http://localhost:8888`

### **C) Iniciar frontend (Terminal 2):**
```bash
cd /home/user/frontend-openblind
npm run dev
```
Debe correr en: `http://localhost:3000`

### **D) Abrir en navegador:**
```
http://localhost:3000
```

Deberías ver:
- Dashboard con 4 módulos
- Botón de voz funcional
- Navegación por voz ("Lugares", "Contactos")
- Botón de login en navbar

---

## ⏰ **PASO 3: COMPLETAR LO QUE FALTA (8-10 horas)**

### **📍 CRUD Lugares Favoritos (3 horas)**

Crear estos archivos:

**1. `/src/pages/LugaresFavoritos/index.jsx`**
```jsx
import { useState, useEffect } from 'react'
import Navbar from '../../components/Navbar'
import VoiceButton from '../../components/VoiceButton'
import Button from '../../components/Button'
import lugaresService from '../../services/lugaresService'
import { useVoiceCommands, hablar } from '../../hooks/useVoiceCommands'

function LugaresFavoritos() {
  const [lugares, setLugares] = useState([])
  const [showForm, setShowForm] = useState(false)
  const [lugarEditar, setLugarEditar] = useState(null)

  // Cargar lugares al inicio
  useEffect(() => {
    cargarLugares()
  }, [])

  const cargarLugares = async () => {
    try {
      const data = await lugaresService.getAll()
      setLugares(data)
    } catch (error) {
      console.error(error)
    }
  }

  // Comandos de voz
  const handleVoiceCommand = async (command) => {
    if (command.includes('agregar')) {
      setShowForm(true)
      hablar('Abriendo formulario para agregar lugar')
    }

    if (command.includes('ir a')) {
      const nombreLugar = command.replace('ir a', '').trim()
      const lugar = lugares.find(l =>
        l.nombreLugar.toLowerCase().includes(nombreLugar)
      )
      if (lugar) {
        navegarALugar(lugar)
      }
    }
  }

  const { isListening, toggleListening } = useVoiceCommands(handleVoiceCommand)

  const navegarALugar = (lugar) => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(lugar.direccion)}`
    window.open(url, '_blank')
    hablar(`Abriendo navegación a ${lugar.nombreLugar}`)
  }

  const eliminarLugar = async (id) => {
    if (confirm('¿Eliminar este lugar?')) {
      await lugaresService.delete(id)
      cargarLugares()
      hablar('Lugar eliminado')
    }
  }

  return (
    <div>
      <Navbar title="Lugares Favoritos" showBack={true} />

      <div className="content">
        {/* Lista de lugares */}
        {lugares.map(lugar => (
          <div key={lugar.idLugar} className="item-card">
            <div className="item-info">
              <h3>{lugar.nombreLugar}</h3>
              <p>{lugar.direccion}</p>
            </div>
            <div className="item-actions">
              <Button onClick={() => navegarALugar(lugar)} size="small">
                Ir
              </Button>
              <Button onClick={() => setLugarEditar(lugar)} size="small" variant="secondary">
                Editar
              </Button>
              <Button onClick={() => eliminarLugar(lugar.idLugar)} size="small" variant="danger">
                Eliminar
              </Button>
            </div>
          </div>
        ))}

        <Button onClick={() => setShowForm(true)} fullWidth variant="ghost">
          + Agregar Lugar
        </Button>
      </div>

      <VoiceButton isListening={isListening} onToggle={toggleListening} />
    </div>
  )
}

export default LugaresFavoritos
```

**2. Crear formulario similar** para agregar/editar

**3. Agregar estilos CSS**

---

### **👥 CRUD Contactos Emergencia (3 horas)**

Similar a Lugares pero con:
- Campo prioridad (1, 2, 3)
- Campo relación (Mamá, Papá, Médico)
- Botón "Llamar" que hace `window.location.href = 'tel:' + telefono`
- Botón "Emergencia" que llama al prioritario

---

### **📍 Ubicación Actual (1 hora)**

**`/src/pages/UbicacionActual.jsx`**
```jsx
import { useState, useEffect } from 'react'

function UbicacionActual() {
  const [ubicacion, setUbicacion] = useState(null)

  useEffect(() => {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setUbicacion({
          lat: position.coords.latitude,
          lng: position.coords.longitude
        })
      }
    )
  }, [])

  return (
    <div>
      <Navbar title="Mi Ubicación" showBack={true} />

      {ubicacion && (
        <div>
          <p>Latitud: {ubicacion.lat}</p>
          <p>Longitud: {ubicacion.lng}</p>
          <Button onClick={() => guardarComoLugar()}>
            Guardar como Lugar Favorito
          </Button>
        </div>
      )}
    </div>
  )
}
```

---

### **🔐 Login (1 hora)**

**`/src/pages/Login.jsx`**
```jsx
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const navigate = useNavigate()

  const handleLogin = async () => {
    // TODO: Llamar API de login
    navigate('/')
  }

  return (
    <div>
      <Navbar title="Login" showBack={true} showLogin={false} />

      <div className="login-form">
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Email"
        />
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Contraseña"
        />
        <Button onClick={handleLogin} fullWidth>
          Iniciar Sesión
        </Button>
      </div>
    </div>
  )
}
```

---

## 📚 **RECURSOS:**

- **Documentación completa:** `PROGRESO.md`
- **Backend:** `/home/user/estructura-hexagonal`
- **Frontend:** `/home/user/frontend-openblind`

---

## ❓ **SI TIENES DUDAS:**

1. Revisa los componentes ya creados en `/src/components`
2. Revisa el Dashboard en `/src/pages/Dashboard.jsx`
3. Usa los servicios en `/src/services`
4. El hook de voz está en `/src/hooks/useVoiceCommands.js`

---

## ✅ **CHECKLIST ENTREGABLE:**

- [x] Backend con CRUD Contactos ✅
- [x] Frontend estructura completa ✅
- [x] Dashboard funcional ✅
- [x] Comandos de voz configurados ✅
- [ ] CRUD Lugares completo (tú)
- [ ] CRUD Contactos completo (tú)
- [ ] Ubicación básica (tú)
- [ ] Login básico (tú)
- [ ] Probar todo el flujo
- [ ] Preparar demo

---

**¡ÉXITO! 🚀**

Todo está listo para que continúes. El 80% del trabajo pesado ya está hecho.
